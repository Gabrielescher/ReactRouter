function Contact() {
    return (
      <div>
        <h1>Contact Page</h1>
        <p>Get in touch via the Contact Page!</p>
      </div>
    );
  }
  
  export default Contact;
  